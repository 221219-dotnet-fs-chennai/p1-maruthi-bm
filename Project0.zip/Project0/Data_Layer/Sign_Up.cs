﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer
{
    public class Sign_Up
    {
        public int Trainer_id { get; set; }
        public string FullName { get; set; }
        public string email { get; set; }
        public string Password { get; set; }

        public Sign_Up() { }
        public Sign_Up(int Trainer_id, string FullName, string email, string Password)
        {
            this.Trainer_id = Trainer_id;
            this.FullName = FullName;
            this.email = email;
            this.Password = Password;

        }
        public override string ToString()
        {
            return $"{Trainer_id},{FullName},{email},{Password} ";

        }
    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer
{
    public class Education
    {
        public int Trainer_id { get; set; }
        public string Degree { get; set; }
        public string institute_name { get; set; }
        public string start_date { set; get; }
        public string end_date { set; get; }
        public int grade { get; set; }
        public decimal CGPA { get; set; }
        public Education() { }
        public Education(int Trainer_id, string Degree, string institute_name, string start_date, string end_date, int grade, decimal CGPA)
        {
            this.Trainer_id = Trainer_id;
            this.Degree = Degree;
            this.institute_name = institute_name;
            this.start_date = start_date;
            this.end_date = end_date;
            this.grade = grade;
            this.CGPA = CGPA;
        }
        public override string ToString()
        {
            return $"{Trainer_id},{Degree},{institute_name},{start_date},{end_date},{grade},{CGPA} ";
        }

    }

}



﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer
{
    public class User_Details
    {
        public int Trainer_id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public int Age { get; set; }
        public string Password { get; set; }
        public string Gender { get; set; }
        public string Location { get; set; }
        public string Domain { get; set; }

        public User_Details() { }
        public User_Details(int trainer_id, string name, string address, int age, string password, string gender, string location, string domain)
        {
            this.Trainer_id = trainer_id;
            this.Name = name;
            this.Address = address;
            this.Age = age;
            this.Password = password;
            this.Gender = gender;
            this.Location = location;
            this.Domain = domain;
        }

        public override string ToString()
        {
            return $" {Trainer_id},{Name},{Address},{Age},{Password},{Gender},{Location},{Domain} ";
        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer
{
    public class Skills
    {
        public int Trainer_id { get; set; }
        public string skills_1 { get; set; }
        public string skills_2 { get; set; }
        public string Certificate { get; set; }

        public Skills() { }
       
        public override string ToString()
        {
            return $"{Trainer_id},{skills_1},{skills_2},{Certificate} ";

        }
    }
}


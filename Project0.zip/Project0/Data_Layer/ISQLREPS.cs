﻿using Data_Layer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer
{
    public interface ISQLREPS
    {
        public User_Details Add(User_Details user);
        List<User_Details> GetUser_Details();
        public Skills Add(Skills user);
       List<Skills> GetSkills();
        public contact Add(contact user);
        List<contact> GetContacts();
        public Company Add(Company user);
        List<Company> GetCompanys();
        public Education Add(Education user);
        List<Education> GetEducation();
        public Sign_Up Add(Sign_Up user);
        List<Sign_Up> GetSign_Up();
        public  void UpdateUser(User_Details user);
        public void DeleteAcc(int id);
        public void DeleteUser(int id, string name);
        public void DeleteEdu(int id, string degree);
        public void DeleteSkill(int id, string skill);
        public void DeleteCom(int id, string compay);


    }
}


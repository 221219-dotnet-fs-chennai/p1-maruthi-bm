﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer
{
    public class Company
    {
        public int Trainer_id { get; set; }
        public string TrainerCompany { get; set; }
        public string industry { get; set; }
        public string strat_date { get; set; }
        public string end_date { get; set; }
        public Company() { }
        public Company(int trainer_id, string trainercompany, string industry, string strat_date, string end_date)
        {
            this.Trainer_id = trainer_id;
            this.TrainerCompany = trainercompany;
            this.industry = industry;
            this.strat_date = strat_date;
            this.end_date = end_date;
        }

        public override string ToString()
        {
            return $"{Trainer_id},{TrainerCompany},{industry},{strat_date},{end_date} ";
        }
    }
}


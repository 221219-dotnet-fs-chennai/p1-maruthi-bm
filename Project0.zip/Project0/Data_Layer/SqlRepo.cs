﻿using Data_Layer;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Data_Layer
{
    public class SqlRepo : ISQLREPS
    {       //using readonly to make the conection
        //using readonly we canot concatinate string because string is imutable on nature
        private readonly string connectionString;
        public SqlRepo(string connectionString)
        {
            this.connectionString = "Server=tcp:associateserver.database.windows.net,1433;Initial Catalog=AssociatesDb;Persist Security Info=False;User ID=associate;Password=Password123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
        }

        //user__Details table
        public User_Details Add(User_Details user)
        {

            using SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            string query = @"INSERT INTO Maruthi.User_Details ([Trainer_id],[Name],[Address],[Age],[Password],[Gender],[Location],[Domain]) values(@Trainer_id,@Name,@Address,@Age,@Password,@Gender,@Location,@Domain) ";
            SqlCommand command = new SqlCommand(query, con);//it execute the sql statment

            command.Parameters.AddWithValue("@Trainer_id", user.Trainer_id);
            command.Parameters.AddWithValue("@Name", user.Name);
            command.Parameters.AddWithValue("@Address", user.Address);
            command.Parameters.AddWithValue("@Age", user.Age);
            command.Parameters.AddWithValue("@Password", user.Password);
            command.Parameters.AddWithValue("@Gender", user.Gender);
            command.Parameters.AddWithValue("@Location", user.Location);
            command.Parameters.AddWithValue("@Domain", user.Domain);
            int n = command.ExecuteNonQuery();
            Console.WriteLine("succed");

            return user;
        }
        public List<User_Details> GetUser_Details()
        {
            List<User_Details> users = new List<User_Details>();
            using SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            string query = " select * FROM Maruthi.User_Details; ";
            SqlCommand command = new SqlCommand(query, con);
            //for reading the details in the database
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                users.Add(new User_Details()
                {
                    Trainer_id = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    Address = reader.GetString(2),
                    Age = reader.GetInt32(3),
                    Password = reader.GetString(4),
                    Gender = reader.GetString(5),
                    Location = reader.GetString(6),
                    Domain = reader.GetString(7),
                });
            }
            return users;
        }

        //Skills table

        public Skills Add(Skills user)
        {
            Console.WriteLine(user.skills_2 + "hi");
            string query = "INSERT INTO Maruthi.Skills (Trainer_id,skills_1,skills_2,Certificate) Values (@Trainer_id,@skills_1,@skills_2,@Certificate)";
            using SqlConnection con = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand(query, con);
            con.Open();
            command.Parameters.AddWithValue("@Trainer_id", user.Trainer_id);
            command.Parameters.AddWithValue("@skills_1", user.skills_1);
            command.Parameters.AddWithValue("@skills_2", user.skills_2);
            command.Parameters.AddWithValue("@Certificate", user.Certificate);
            int n = command.ExecuteNonQuery();
            Console.WriteLine("succed");

            return user;
        }

        public List<Skills> GetSkills()
        {
            List<Skills> users = new List<Skills>();
            using SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            string query = "SELECT [Trainer_id],[skills_1],[skills_2],[Certificate] FROM Maruthi.Skills";
            SqlCommand command = new SqlCommand(query, con);
            //for executing
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                users.Add(new Skills()
                {
                    Trainer_id = reader.GetInt32(0),
                    skills_1 = reader.GetString(1),
                    skills_2 = reader.GetString(2),
                    Certificate = reader.GetString(3),
                });
            }
            return users;
        }
        //contact table:
        public contact Add(contact user)
        {
            string query = "INSERT INTO Maruthi.contact (Trainer_id,email,website,phone_no,Social_Media) values(@Trainer_id,@email,@website,@phone_no,@Social_Media) ";
            using SqlConnection con = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand(query, con);
            con.Open();
            command.Parameters.AddWithValue("@Trainer_id", user.Trainer_id);
            command.Parameters.AddWithValue("@email", user.email);
            command.Parameters.AddWithValue("@website", user.website);
            command.Parameters.AddWithValue("@phone_no", user.phone_no);
            command.Parameters.AddWithValue("Social_Media", user.Social_Media);
            int n = command.ExecuteNonQuery();
            Console.WriteLine("succed");

            return user;
        }


        public List<contact> GetContacts()
        {
            List<contact> users = new List<contact>();
            using SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            string query = "SELECT [Trainer_id],[email],[website],[phone_no],[Social_Media] FROM Maruthi.contact";
            SqlCommand command = new SqlCommand(query, con);
            //for executing
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                users.Add(new contact()
                {
                    Trainer_id = reader.GetInt32(0),
                    email = reader.GetString(1),
                    website = reader.GetString(2),
                    phone_no = reader.GetString(3),
                    Social_Media = reader.GetString(4),
                });
            }
            return users;

        }
        //company table:

        public Company Add(Company user)
        {
            string query = "INSERT INTO Maruthi.Company(Trainer_id,TrainerCompany,industry,strat_date,end_date)values(@Trainer_id,@TrainerCompany,@industry,@strat_date,@end_date)";
            using SqlConnection con = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand(query, con);
            con.Open();
            command.Parameters.AddWithValue("@Trainer_id", user.Trainer_id);
            command.Parameters.AddWithValue("@TrainerCompany", user.TrainerCompany);
            command.Parameters.AddWithValue("@industry", user.industry);
            command.Parameters.AddWithValue("@strat_date", user.strat_date);
            command.Parameters.AddWithValue("end_date", user.end_date);
            int n = command.ExecuteNonQuery();
            Console.WriteLine("succed");

            return user;
        }

        public List<Company> GetCompanys()
        {
            List<Company> users = new List<Company>();
            using SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            string query = "SELECT [Trainer_id],[TrainerCompany],[industry],[strat_date],[end_date] FROM Maruthi.Company";
            SqlCommand command = new SqlCommand(query, con);
            //for executing
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                users.Add(new Company()
                {
                    Trainer_id = reader.GetInt32(0),
                    TrainerCompany = reader.GetString(1),
                    industry = reader.GetString(2),
                    strat_date = reader.GetString(3),
                    end_date = reader.GetString(4),
                });
            }
            return users;

        }
        //education table :

        public Education Add(Education user)
        {
            string query = "INSERT INTO Maruthi.Education (Trainer_id,Degree,institute_name,start_date,end_date,grade,CGPA)values(@Trainer_id,@Degree,@institute_name,@start_date,@end_date,@grade,@CGPA)";
            using SqlConnection con = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand(query, con);
            con.Open();
            command.Parameters.AddWithValue("@Trainer_id", user.Trainer_id);
            command.Parameters.AddWithValue("@Degree", user.Degree);
            command.Parameters.AddWithValue("@institute_name", user.institute_name);
            command.Parameters.AddWithValue("@start_date", user.start_date);
            command.Parameters.AddWithValue("@end_date", user.end_date);
            command.Parameters.AddWithValue("@grade", user.grade);
            command.Parameters.AddWithValue("@CGPA", user.CGPA);
            int n = command.ExecuteNonQuery();
            Console.WriteLine("succed");

            return user;
        }

        public List<Education> GetEducation()
        {
            List<Education> users = new List<Education>();
            using SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            string query = "SELECT [Trainer_id],[Degree],[institute_name],[start_date],end_date,[grade],[CGPA] FROM Maruthi.Education ";
            SqlCommand command = new SqlCommand(query, con);
            //for executing
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                users.Add(new Education()
                {
                    Trainer_id = reader.GetInt32(0),
                    Degree = reader.GetString(1),
                    institute_name = reader.GetString(2),
                    start_date = reader.GetString(3),
                    end_date = reader.GetString(4),
                    grade = reader.GetInt32(5),
                    CGPA = reader.GetDecimal(6),

                });
            }
            return users;
        }

        //signup table :

        public Sign_Up Add(Sign_Up user)
        {
            string query = "INSERT INTO Maruthi.Sign_Up (Trainer_id,FullName,email,Password)";
            using SqlConnection con = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand(query, con);
            con.Open();
            command.Parameters.AddWithValue("@Trainer_id", user.Trainer_id);
            command.Parameters.AddWithValue("@FullName", user.FullName);
            command.Parameters.AddWithValue("@email", user.email);
            command.Parameters.AddWithValue("@Password", user.Password);
            int n = command.ExecuteNonQuery();
            Console.WriteLine("succed");

            return user;
        }

        public List<Sign_Up> GetSign_Up()
        {
            List<Sign_Up> users = new List<Sign_Up>();
            using SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            string query = "SELECT [Trainer_id],[FullName],[email],[Password]";
            SqlCommand command = new SqlCommand(query, con);
            //for executing
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                users.Add(new Sign_Up()
                {
                    Trainer_id = reader.GetInt32(0),
                    FullName = reader.GetString(1),
                    email = reader.GetString(2),
                    Password = reader.GetString(3)
                });
            }
            return users;

        }
        //to check user login
        public bool checkUser(int Trainer_id, string password)
        {

            List<string> newList = new();
            string query = $"select [Trainer_id],[Password] from Maruthi.User_Details where Trainer_id = '{Trainer_id}' and password ='{password}' ";
            using SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand command = new SqlCommand(query, con);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                if (Convert.ToString(reader[0]) == Convert.ToString(Trainer_id) && Convert.ToString(reader[1]) == password)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;

        }
        public void DeleteAcc(int id)
        {
            using SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            string query = $"Delete from Maruthi.User_Details where [Trainer_iD] = {id} ";
            SqlCommand command = new SqlCommand(query, con);
            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows affected");
        }

        public void DeleteUser(int id, string name)
        {
            using SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            string query = $"Delete from Maruthi.User_Details where [Trainer_iD] = {id} and  [Name] = '{name}'";
            SqlCommand command = new SqlCommand(query, con);
            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows affected");
        }


        public void DeleteEdu(int id, string degree)
        {
            using SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            string query = $"Delete from Maruthi.Education where [Trainer_iD] = {id} and [Degree] = '{degree}' ";
            SqlCommand command = new SqlCommand(query, con);
            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows affected");
        }


        public void DeleteSkill(int id, string skill)
        {
            using SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            string query = $"Delete from Maruthi.Skills where [Trainer_iD] = {id} and [skills_1] = '{skill}'";
            SqlCommand command = new SqlCommand(query, con);
            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows affected");
        }

        public void DeleteCom(int id, string compay)
        {
            using SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            string query = $"Delete from Maruthi.Company where [Trainer_iD] = {id} and  [TrainerCompany] = '{compay}'";
            SqlCommand command = new SqlCommand(query, con);
            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows affected");
        }

        //update
        public void UpdateUser(User_Details ud)
        {
           

            string query = $"update Maruthi.User_Details set [Name] = '{ud.Name}', [Address] = '{ud.Address}', [Gender] = '{ud.Gender}', [Password] = '{ud.Password}' where [Trainer_id] = {ud.Trainer_id};";
            using SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            using SqlCommand cmd = new SqlCommand(query, con);
            //cmd.Parameters.AddWithValue("@name", ud.Name);
            //cmd.Parameters.AddWithValue("@address", ud.Address);
            //cmd.Parameters.AddWithValue("@gender", ud.Gender);
            //cmd.Parameters.AddWithValue("@password", ud.Password);
            cmd.ExecuteNonQuery();
        }
        //check user is present or not

        public int GetTrainer_id(string Password)
        {
            int id = 0;
            string query = $"select [Trainer_ID] from Maruthi.User_Details where Email = '{Password}';";
            using SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand command = new SqlCommand(query, con);
            id = Convert.ToInt32(command.ExecuteScalar());
            return id;
        }

    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer
{
    public class contact
    {
        public int Trainer_id { get; set; }
        public string email { get; set; }
        public string website { get; set; }
        public string phone_no { get; set; }
        public string Social_Media { get; set; }
        public contact() { }
        public contact(int trainer_id, string email, string website, string phone_no, string social_Media)
        {
            this.Trainer_id = trainer_id;
            this.email = email;
            this.website = website;
            this.phone_no = phone_no;
            this.Social_Media = social_Media;
        }

        public override string ToString()
        {
            return $"{Trainer_id},{email},{website},{phone_no},{Social_Media} ";
        }
    }
}



﻿using Data_Layer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UI_Layer;

namespace UI_lAYER
{
    public class View : IMenu
    {
        private static readonly string conStr = "server=tcp:associateserver.database.windows.net,1433;initial catalog=associatesdb;persist security info=false;user id=associate;password=Password123;multipleactiveresultsets=false;encrypt=true;trustservercertificate=false;connection timeout=30";
        ISQLREPS newsqlRepo = new SqlRepo(conStr);
        User_Details newUser = new();
        public void Display()
        {
            Console.WriteLine("-----------------------------------------**************-----------------------------------------");
            Console.WriteLine("Enter [1] for VIEW  All DATA");
            Console.WriteLine("-----------------------------------------**************-----------------------------------------");
            Console.WriteLine("Enter [2] for MAIN MENU");
            Console.WriteLine("-----------------------------------------**************-----------------------------------------");
            Console.WriteLine("Enter [b] for back");
            Console.WriteLine("-----------------------------------------**************-----------------------------------------");
        }

        public string UserOption()
        {
            string userInput = Console.ReadLine();
            switch (userInput)
            {
                case "b":
                    return "Back";
                case "1":
                    List<User_Details> newList = newsqlRepo.GetUser_Details();
                    foreach (var item in newList)
                    {
                        Console.WriteLine(@$"
{item.Name} - {item.Address} - {item.Age} - {item.Gender} - {item.Location} - {item.Domain}");
                        Console.ReadKey();
                    }
                    List<Education> newL = newsqlRepo.GetEducation();
                    foreach (var ite in newL)
                    {
                        Console.WriteLine(@$"
{ite.Degree} - {ite.institute_name} - {ite.start_date} - {ite.end_date} - {ite.grade}");
                        Console.ReadKey();
                    }
                    List<Skills> newk = newsqlRepo.GetSkills();
                    foreach (var itt in newk)
                    {
                        Console.WriteLine(@$"
{itt.skills_1} - {itt.skills_2} - {itt.Certificate}");
                        Console.ReadKey();
                    }
                    List<Company> neL = newsqlRepo.GetCompanys();
                    foreach (var ie in neL)
                    {
                        Console.WriteLine(@$"
{ie.TrainerCompany} - {ie.industry} - {ie.strat_date} - {ie.end_date} ");
                        Console.ReadKey();
                    }
                    List<contact> neLL = newsqlRepo.GetContacts();
                    foreach (var ie in neLL)
                    {
                        Console.WriteLine(@$"
{ie.email} - {ie.website} - {ie.phone_no} - {ie.Social_Media} ");
                        Console.ReadKey();
                    }
                    return "View";
                case "2":
                    return "Menu";
                default:
                    Console.WriteLine("enter a valid option, please press enter to try again");
                    Console.ReadKey();
                    return "View";
            }
        }

    }
}



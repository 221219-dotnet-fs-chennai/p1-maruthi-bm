﻿using Data_Layer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using UI_Layer;

namespace UI_lAYER
{
    public class update : IMenu
    {
        private static readonly string conStr = "server=tcp:associateserver.database.windows.net,1433;initial catalog=associatesdb;persist security info=false;user id=associate;password=Password123;multipleactiveresultsets=false;encrypt=true;trustservercertificate=false;connection timeout=30";
        ISQLREPS newsqlRepo = new SqlRepo(conStr);
        User_Details newUser = new();
        public void Display()
        {
            Console.WriteLine("====================================");
            Console.WriteLine("         Update Your DATA           ");
            Console.WriteLine("====================================");
            Console.WriteLine("Enter [b] for Back");
            Console.WriteLine("Enter [1] for update your User_Details");
            Console.WriteLine("Enter [2] for update your skills");
            Console.WriteLine("Enter [3] for update your Education");
            Console.WriteLine("Enter [4] for update your contact");
        }

        public string UserOption()
        {
            string usin = Console.ReadLine();
            switch (usin)
            {
                case "b":
                    return "Back";
                case "1":
                    Console.WriteLine("Enter your user Name data");

                    return "userUpdate";
                case "2":
                    Console.WriteLine("Enter your Address update data");
                    return "update";
                case "3":
                    Console.WriteLine("Enter your Gender update data");
                    return "update";
                case "4":
                    Console.WriteLine("Enter your Password update data");
                    return "update";

                default:
                    Console.WriteLine(" Enter vaild data");
                    return "update";
            }
        }
    }
}

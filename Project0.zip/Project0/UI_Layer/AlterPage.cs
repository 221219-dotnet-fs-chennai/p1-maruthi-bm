﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UI_Layer
{
    public class AlterPage : IMenu
    {
        public void Display()
        {
            Console.WriteLine("---------------------------************-------------------------");
            Console.WriteLine("       WELCOME        ");
            Console.WriteLine("---------------------------************-------------------------");
            Console.WriteLine("Enter  [0]  for Exit");
            Console.WriteLine("---------------------------************-------------------------");
            Console.WriteLine("Enter  [1]  for veiw");
            Console.WriteLine("---------------------------************-------------------------");
            Console.WriteLine("Enter  [2]  for update");
            Console.WriteLine("---------------------------************-------------------------");
            Console.WriteLine("Enter  [3]  for delete");
            Console.WriteLine("---------------------------************-------------------------");
        }
        public string UserOption()
        {
            string userInput = Console.ReadLine();
            switch (userInput)
            {
                case "0":
                    return "Exit";
                case "1":
                    return "veiw";
                case "2":
                    return "update";
                case "3":
                    return "Delete";
                default:
                    return "Exit";
            }
        }
    }
}

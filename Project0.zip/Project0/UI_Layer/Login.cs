﻿using Data_Layer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UI_lAYER;

namespace UI_Layer
{
    public class Login : IMenu
    {
        private static Data_Layer.User_Details userdetail = new Data_Layer.User_Details();
        private static string cs = "Server=tcp:associateserver.database.windows.net,1433;Initial Catalog=AssociatesDb;Persist Security Info=False;User ID=associate;Password=Password123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
        SqlRepo newSql = new SqlRepo(cs);
       public static int TID = 0;

        public string UserOption()
        {
            string userInput = Console.ReadLine();
            switch (userInput)
            {
                case "1":
                    Console.WriteLine("Enter your Trainer_id : ");
                    userdetail.Trainer_id = Convert.ToInt32(Console.ReadLine());
                    TID = userdetail.Trainer_id;
                    return "Login";

                case "2":
                    Console.WriteLine("Enter your Password : ");
                    userdetail.Password = Console.ReadLine();
                    return "Login";
              
                case "3":

                    Console.WriteLine("to login");
                   // TID = SqlRepo.GetTrainer_id(Password);
                    if (newSql.checkUser(userdetail.Trainer_id, userdetail.Password)) {
                        userUpdate usrdet = new userUpdate(userdetail);
                        return "AlterPage";
                    }
                    

                  else {
                        Console.WriteLine("Emil id and Password is Incorect");
                        Console.WriteLine("Press Enter To Try Aggain");
                        Console.ReadKey();
                        return "Login";
                    }
              
                    
             

                case "b":
                    return "Back";

              

                default:
                    Console.WriteLine("Please Input a valid response");
                    Console.WriteLine("Please press enter to continue");
                    Console.ReadLine();
                    return "Login";
            }
        }
        public static int Id()
        {
            return TID;
        }

        void IMenu.Display()
        {
            Console.WriteLine("Please Enter your Registered Emnail_id and Password to Login : ");
            Console.WriteLine("[1] Trainer_Id:- " + userdetail.Trainer_id);
            Console.WriteLine("[2] Password :- " + userdetail.Password);
            Console.WriteLine("[3] Next ");
            Console.WriteLine("[b] Back");
         
        }
    }
}























































































































































































































































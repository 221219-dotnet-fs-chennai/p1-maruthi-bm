﻿using Data_Layer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UI_Layer
{
    public class signup : IMenu
    {
        private static Data_Layer.Sign_Up newUser = new Data_Layer.Sign_Up();
        private static Data_Layer.User_Details userdetail= new Data_Layer.User_Details();
        private static Data_Layer.Education education = new Data_Layer.Education();
        private static Data_Layer.Company company = new Data_Layer.Company();
        private static Data_Layer.contact usercontact=new Data_Layer.contact();
        private static Data_Layer.Skills skills= new Data_Layer.Skills();
        private static string cs = "Server=tcp:associateserver.database.windows.net,1433;Initial Catalog=AssociatesDb;Persist Security Info=False;User ID=associate;Password=Password123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
        ISQLREPS newSql = new SqlRepo(cs);

        public void Display()
        {
            Console.WriteLine("\t \t Please Enter your Details : ");
            Console.WriteLine("------------------------------------------------------------------------------------------------");
            Console.WriteLine("-----------------------------------------**************-----------------------------------------");
            Console.WriteLine("------------------------------------------------------------------------------------------------");
            Console.WriteLine("\t \t  Enter User_Details");
            Console.WriteLine("[1] Trainer_id : " + userdetail.Trainer_id);
            Console.WriteLine("[2] Name : " + userdetail.Name);
            Console.WriteLine("[3] Gender : " + userdetail.Gender);
            Console.WriteLine("[4] Location : " + userdetail.Location);
            Console.WriteLine("[5] Address : " + userdetail.Address);
            Console.WriteLine("[a] password :" +userdetail.Password);
            Console.WriteLine("[6] Age : " + userdetail.Age);
            Console.WriteLine("[7] Domain : " + userdetail.Domain);
            Console.WriteLine("------------------------------------------------------------------------------------------------");
            Console.WriteLine("-----------------------------------------**************-----------------------------------------");
            Console.WriteLine("------------------------------------------------------------------------------------------------");
            Console.WriteLine("\t \t Enter The Education Details");
            Console.WriteLine("[8] Degree : " + education.Degree);
            Console.WriteLine("[9] institute_name : " + education.institute_name);
            Console.WriteLine("[10] start_date : " + education.start_date);
            Console.WriteLine("[11] end_date : " + education.end_date);
            Console.WriteLine("[12] grade : " + education.grade);
            Console.WriteLine("[13] CGPA : " + education.CGPA);
            Console.WriteLine("------------------------------------------------------------------------------------------------");
            Console.WriteLine("-----------------------------------------**************-----------------------------------------");
            Console.WriteLine("------------------------------------------------------------------------------------------------");
            Console.WriteLine("\t \t Enter The Company Details");
            Console.WriteLine("[14] company : " + company.TrainerCompany);
            Console.WriteLine("[15] industry : " + company.industry);
            Console.WriteLine("[16] strat_date : " + company.strat_date);
            Console.WriteLine("[17] end_date : " + company.end_date);
            Console.WriteLine("------------------------------------------------------------------------------------------------");
            Console.WriteLine("-----------------------------------------***********-------------------------------------------");
            Console.WriteLine("\t \t Enter The User Contact");
            Console.WriteLine("[18] email : " + usercontact.email);
            Console.WriteLine("[19] website : " + usercontact.website);
            Console.WriteLine("[20] phone_no : " + usercontact.phone_no);
            Console.WriteLine("[21] SocialMedia : " + usercontact.Social_Media);
            Console.WriteLine("------------------------------------------------------------------------------------------------");
            Console.WriteLine("-----------------------------------------***********-------------------------------------------");
            Console.WriteLine("\t \t Enter your Skills");
            Console.WriteLine("[22] skills_1 : " + skills.skills_1);
            Console.WriteLine("[23] skills_2 : " + skills.skills_2);
            Console.WriteLine("[24] Certificate : " + skills.Certificate);
            Console.WriteLine("------------------------------------------------------------------------------------------------");
            Console.WriteLine("-----------------------------------------***********-------------------------------------------");
            Console.WriteLine("[25] Save");
            Console.WriteLine("------------------------------------------------------------------------------------------------");
            Console.WriteLine("-----------------------------------------**************-----------------------------------------");
            Console.WriteLine("[26] Back");
            Console.WriteLine("-----------------------------------------**************-----------------------------------------");


        }
        string IMenu.UserOption()
        {  
            string userInput = Console.ReadLine();
            switch (userInput)
            {
                case "1":
                    Console.WriteLine("Enter your Trainer_id : ");
                    userdetail.Trainer_id = Convert.ToInt32(Console.ReadLine());
                    skills.Trainer_id = userdetail.Trainer_id;
                    return "signup";

                case "2":
                    Console.WriteLine("Enter your Name : ");
                    userdetail.Name = Console.ReadLine();
                    return "signup";

                case "3":
                    Console.WriteLine("Enter your Gender : ");
                      userdetail.Gender = Console.ReadLine();
                    return "signup";

                case "4":
                    Console.WriteLine("Enter your  Location : ");
                    userdetail.Location = Console.ReadLine();
                    return "signup";

                case "5":
                    Console.WriteLine("Enter your  Address : ");
                    userdetail.Address = Console.ReadLine();
                    return "signup";
                case "a":
                    Console.WriteLine("enter the password :");
                    userdetail.Password = Console.ReadLine();
                    return "signup";


                case "6":
                    Console.WriteLine("Enter your  Age : ");
                    userdetail.Age = Convert.ToInt32(Console.ReadLine());
                    return "signup";

                case "7":
                    Console.WriteLine("Enter your  Domain : ");
                    userdetail.Domain = Console.ReadLine();
                    return "signup";
                case "8":
                    Console.WriteLine("Enter your Degree : ");
                    education.Degree = Console.ReadLine();
                    return "signup";

                case "9":
                    Console.WriteLine("Enter your institute_name : ");
                    education.institute_name = Console.ReadLine();
                    return "signup";

                case "10":
                    Console.WriteLine("Enter your  start_date : ");
                    education.start_date = Console.ReadLine();
                    return "signup";

                case "11":
                    Console.WriteLine("Enter your  end_date : ");
                    education.end_date = Console.ReadLine();
                    return "signup";

                case "12":
                    Console.WriteLine("Enter your  grade : ");
                    education.grade = Convert.ToInt32(Console.ReadLine());
                    return "signup";

                case "13":
                    Console.WriteLine("Enter your  CGPA : ");
                    education.CGPA = Convert.ToInt32(Console.ReadLine());
                    return "signup";
                case "14":
                    Console.WriteLine("Enter your company : ");
                    company.TrainerCompany = Console.ReadLine();
                    return "signup";

                case "15":
                    Console.WriteLine("Enter your industry : ");
                    company.industry = Console.ReadLine();
                    return "signup";

                case "16":
                    Console.WriteLine("Enter your  strat_date : ");
                    company.strat_date = Console.ReadLine();
                    return "signup";

                case "17":
                    Console.WriteLine("Enter your  end_date : ");
                    company.end_date = Console.ReadLine();
                    return "signup";
                case "18":
                    Console.WriteLine("Enter your Email : ");
                    usercontact.email = Console.ReadLine();
                    return "signup";
                case "19":
                    Console.WriteLine("enter your website : ");
                    usercontact.website = Console.ReadLine();
                    return "signup";
                case "20":
                    Console.WriteLine("Enter your phone_no : ");
                    usercontact.phone_no = Console.ReadLine();
                    return "signup";
                case "21":
                    Console.WriteLine("Enter the Social_Media");
                    usercontact.Social_Media = Console.ReadLine();
                    return "signup";
                case "22":
                    Console.WriteLine("Enter the skills ");
                    skills.skills_1 = Console.ReadLine();
                    return "signup";
                case "23":
                    Console.WriteLine("Enter the Skills");
                    skills.skills_2 = Console.ReadLine();
                    return "signup";
                case "24":
                    Console.WriteLine("Enter the Certificate");
                    skills.Certificate = Console.ReadLine();
                    return "signup";
                case "25":
                    Console.WriteLine("to save the data");
                    newSql.Add(userdetail);
                    education.Trainer_id = userdetail.Trainer_id;
                    newSql.Add(education);
                    company.Trainer_id = userdetail.Trainer_id;
                    newSql.Add(company);
                    usercontact.Trainer_id = userdetail.Trainer_id;
                    newSql.Add(usercontact);
                    skills.Trainer_id=userdetail.Trainer_id;
                    newSql.Add(skills);
                    return "signup";
             
                case "26":
                    return "Back";



                default:
                    Console.WriteLine("Please Enter a Valid Input");
                    Console.WriteLine("Please Press Enter to Continue");
                    Console.ReadLine();
                    return "UserDetails";


            }
        }
    }
}
﻿using Data_Layer;
using Serilog;
using System.Reflection.Emit;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using UI_lAYER;
using UI_Layer;

class Program
{
    public static void Main(string[] args)
    {
        /*ISQLREPS sql = new SqlRepo("C:/ReveatuCre/Project0/UI_Layer/ConnectionString.txt");
        sql.GetUser_Details().ForEach(user => Console.WriteLine(user));
        sql.GetSkills().ForEach(user => Console.WriteLine(user));
        sql.GetContacts().ForEach(user => Console.WriteLine(user));
        sql.GetCompanys().ForEach(user => Console.WriteLine(user));
        sql.GetEducation().ForEach(user => Console.WriteLine(user));*/

        string path = "C:/Reveature/Project0/UI_Layer/Database/log.txt";
        if(!File.Exists(path)) 
            File.Create(path);
        Log.Logger = new LoggerConfiguration()
            .WriteTo.File(path, rollingInterval: RollingInterval.Day, rollOnFileSizeLimit: true)
            .CreateLogger();
        Log.Logger.Information("---------Program Starts---------");
        Log.Logger.Information("---------Program Ends---------");
        bool repeat = true;
        IMenu menu = new Menu();
        while(repeat) 
        {
            Console.Clear();
            menu.Display();
            string ans = menu.UserOption();
            switch(ans) 
            {
                case "Menu":
                    Log.Information("Displaying Main Menu: ");
                    menu = new Menu();
                    break;
                case "signup":
                    Log.Information("Displaying signup: ");
                    menu = new signup();
                    break;
                case "Login":
                    Log.Information("Displaying Login: ");
                    menu = new Login();
                    break;
                case "AlterPage":
                    Log.Information("Displaying Alter the user table: ");
                    menu = new AlterPage();
                    break;
                case "veiw":
                    Log.Information("Displaying Alter the veiw table: ");
                    menu = new View();
                    break;
                case "update":
                    Log.Information("Displaying Alter the UpdateProfile table: ");
                    menu = new update();
                    break;
                case "userUpdate":
                    Log.Information("Displaying Alter the UpdateProfile table: ");
                    menu = new userUpdate();
                    break;
                case "Delete":
                    Log.Information("Displaying Alter the Delete Profile table: ");
                    menu = new Delete();
                    break;
                case "Exit":
                    Log.Information("Displaying Main Menu: ");
                    repeat= false;  
                    break;
                case "Back":
                    Log.Information("Displaying Back: ");
                    menu = new Menu();
                    break;

                default:
                    Console.WriteLine("page does not exist !!");
                    Console.WriteLine("please click enter to proceed");
                    Console.ReadLine();
                    break;

            }
        }
        
    }
}


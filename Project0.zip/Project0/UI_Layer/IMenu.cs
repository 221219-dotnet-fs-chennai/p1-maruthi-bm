﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UI_Layer
{
    public interface IMenu
    {
        void Display();
        string UserOption();
    }
}

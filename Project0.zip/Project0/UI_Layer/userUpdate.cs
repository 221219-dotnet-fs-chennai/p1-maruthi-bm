﻿using Data_Layer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UI_Layer;

namespace UI_lAYER
{
    public class userUpdate : IMenu
    {

        public userUpdate() { }
        static User_Details userUp = new User_Details();
        public userUpdate(User_Details details) {
        userUp=details;
        }

       
        private static readonly string conStr = "server=tcp:associateserver.database.windows.net,1433;initial catalog=associatesdb;persist security info=false;user id=associate;password=Password123;multipleactiveresultsets=false;encrypt=true;trustservercertificate=false;connection timeout=30";
        ISQLREPS newsqlRepo = new SqlRepo(conStr);
        public void Display()
        {
            Console.WriteLine($"Enter [1] for change your NAME {userUp.Name}");
            Console.WriteLine($"Enter [2] for change your Address {userUp.Address}");
            Console.WriteLine($"Enter [3] for change your Gender {userUp.Gender}");
            Console.WriteLine($"Enter [4] for change your Password {userUp.Password}");
            Console.WriteLine($"Enter [5] for change your save ");
            Console.WriteLine("Enter [b] for Back");
        }

        public string UserOption()
        {
            string usin = Console.ReadLine();
            switch (usin)
            {
                case "b":
                    return "Back";
                case "1":
                    Console.WriteLine("write your name");
                    userUp.Name = Console.ReadLine();
                    return "userUpdate";
                case "2":
                    Console.WriteLine("write your Address");
                    userUp.Address = Console.ReadLine();
                    return "userUpdate";
                case "3":
                    Console.WriteLine("write your Gender");
                    userUp.Gender = Console.ReadLine();
                    return "userUpdate";
                case "4":
                    Console.WriteLine("write your Password");
                    userUp.Password = Console.ReadLine();
                    return "userUpdate";
                case "5":
                    userUp.Trainer_id = Login.TID;
                    Console.WriteLine("VALUES UPDATED SUCCESSFULLY!");
                    Console.ReadLine();
                    newsqlRepo.UpdateUser(userUp);
                    return "userUpdate";
                default:
                    Console.WriteLine("Enter vaild Number");
                    return "userUpdate";

            }
        }
    }
}


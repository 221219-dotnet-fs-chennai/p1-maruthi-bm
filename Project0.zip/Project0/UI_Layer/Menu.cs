﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UI_Layer
{
    internal class Menu : IMenu
    {
        public void Display() 
        {
            Console.WriteLine("\t \t \n \n \t \t \t \t \t  Welcome to Home Page");
            Console.WriteLine("------------------------------------------------------------------------------------------------");
            Console.WriteLine("-----------------------------------------**************-----------------------------------------");
            Console.WriteLine("\n \n  Select one option from the below : ");
            Console.WriteLine("\t \n [1] for Login");
            Console.WriteLine("\t \n [2] for Sign_Up");
           // Console.WriteLine("\t \n [2] for AlterPage");
            Console.WriteLine("\t \n [3] for Exit");
            Console.WriteLine("------------------------------------------------------------------------------------------------");
            Console.WriteLine("-----------------------------------------**************-----------------------------------------");
            Console.Write("Press The Number  :");
        }
        public string UserOption()
        {
            string usreInput = Console.ReadLine();
            switch(usreInput) 
            {
                case "1":
                    return "Login";
                case "2":
                    return "signup";
              //  case "3":
                //    return "AlterPage";
                case "4":
                    return "Exit";
                default:
                    Console.WriteLine("please give a valid input");
                    Console.WriteLine("To Continue, Please hit a enter key");
                    Console.ReadLine();
                    return "Menu";
            }
        }
    }
}

﻿using Data_Layer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UI_Layer;

namespace UI_lAYER
{
    public class Delete : IMenu
    {
        private static readonly string conStr = "server=tcp:associateserver.database.windows.net,1433;initial catalog=associatesdb;persist security info=false;user id=associate;password=Password123;multipleactiveresultsets=false;encrypt=true;trustservercertificate=false;connection timeout=30";
        ISQLREPS newsqlRepo = new SqlRepo(conStr);
        User_Details newUser = new();
        int id;
        public void Display()
        {
            Console.WriteLine("Enter [b] for Back ");
            Console.WriteLine("Enter [1] for DELETE ACCOUNT");
           // Console.WriteLine("Enter [1] for DELETE USER_DETAILS TABLE");
            Console.WriteLine("Enter [2] for DELETE EDUCATION TABLE");
            Console.WriteLine("Enter [3] for DELETE SKILLS TABLE");
            Console.WriteLine("Enter [4] for DELETE COMPANY TABLE");
        }

        public string UserOption()
        {
            string useriput = Console.ReadLine();
            switch (useriput)
            {
                case "b":
                    return "Back";
                case "1":
                    id = Login.Id();
                    newsqlRepo.DeleteAcc(id);

                    return "DELETE ACCOUNT";
                case "2":
                    int id0 = Login.Id();
                    Console.WriteLine("which id row will you want to delete");
                    string aa = Console.ReadLine();
                    newsqlRepo.DeleteUser(id0, aa);
                    return "DeleteAcc";
                case "3":
                    int id1 = Login.Id();
                    Console.WriteLine("which degree row will you want to delete");
                    string a = Console.ReadLine();
                    newsqlRepo.DeleteEdu(id, a);
                    Console.WriteLine("deleted sucessfully");
                    return "Delete";
                case "4":
                    int id2 = Login.Id();
                    Console.WriteLine("which skill will you want to delete ");
                    string b = Console.ReadLine();
                    newsqlRepo.DeleteSkill(id2, b);
                    return "Delete";
                case "5":
                    int id3 = Login.Id();
                    Console.WriteLine("which company will you want to delete ");
                    string c = Console.ReadLine();
                    newsqlRepo.DeleteCom(id3, c);
                  //  break;
                    return "Delete";
                default:
                    Console.WriteLine(" Please Enter Valid Number :");
                    return "Delete";
            }
        }
    }
}
